package me.longka.neltraproop;

import org.bukkit.plugin.java.JavaPlugin;

public class NeltraProOp extends JavaPlugin {

    private static NeltraProOp instance;
    private OpManager opManager;
    private LoginManager loginManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        opManager    = new OpManager(this);
        loginManager = new LoginManager(this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        NeltraCommand cmd = new NeltraCommand(this);
        getCommand("neltraproop").setExecutor(cmd);
        getCommand("login").setExecutor(cmd);
        getCommand("register").setExecutor(cmd);
        getCommand("pas").setExecutor(cmd);
        getLogger().info("§a[NeltraProOp] §fEnabled! §7Dev For LongKa");
    }

    @Override
    public void onDisable() {
        loginManager.cancelAll();
        getLogger().info("§c[NeltraProOp] §fDisabled.");
    }

    public static NeltraProOp getInstance() { return instance; }
    public OpManager getOpManager()         { return opManager; }
    public LoginManager getLoginManager()   { return loginManager; }
}
