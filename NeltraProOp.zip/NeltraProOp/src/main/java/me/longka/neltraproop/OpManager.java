package me.longka.neltraproop;

import org.bukkit.configuration.file.FileConfiguration;
import java.util.*;

public class OpManager {

    private final NeltraProOp plugin;
    private final Map<String, String> opList = new HashMap<>();

    public OpManager(NeltraProOp plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        opList.clear();
        FileConfiguration cfg = plugin.getConfig();
        if (cfg.isConfigurationSection("op-list")) {
            for (String key : cfg.getConfigurationSection("op-list").getKeys(false)) {
                String pass = cfg.getString("op-list." + key + ".password", "");
                opList.put(key.toLowerCase(), pass);
            }
        }
    }

    public boolean isAllowed(String name) {
        return opList.containsKey(name.toLowerCase());
    }

    public String getPassword(String name) {
        return opList.getOrDefault(name.toLowerCase(), "");
    }
}
