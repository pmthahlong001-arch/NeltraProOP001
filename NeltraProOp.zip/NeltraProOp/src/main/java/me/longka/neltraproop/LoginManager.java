package me.longka.neltraproop;

import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LoginManager {

    private final NeltraProOp plugin;
    private final Set<UUID> authenticated = ConcurrentHashMap.newKeySet();
    private final Map<UUID, ScheduledTask> loginTimers = new ConcurrentHashMap<>();
    private final Map<UUID, String> playerIPs = new ConcurrentHashMap<>();
    private static final int LOGIN_TIMEOUT_TICKS = 20 * 60 * 5;

    public LoginManager(NeltraProOp plugin) {
        this.plugin = plugin;
    }

    public void onOpJoin(Player player) {
        UUID uuid = player.getUniqueId();
        playerIPs.put(uuid, player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress() : "");

        ScheduledTask task = player.getScheduler().runDelayed(plugin, t -> {
            if (!isAuthenticated(uuid)) {
                Player p = Bukkit.getPlayer(uuid);
                String ip = playerIPs.getOrDefault(uuid, "");
                if (!ip.isEmpty()) {
                    Bukkit.getBanList(BanList.Type.IP).addBan(ip,
                            "§c[NeltraProOp] Không login trong 5 phút!", null, "NeltraProOp");
                }
                if (p != null && p.isOnline()) {
                    p.kickPlayer("§c[NeltraProOp] §fBị §cban IP §fdo không login trong §e5 phút§f!\n§7Dev For LongKa");
                }
                cleanup(uuid);
            }
        }, null, LOGIN_TIMEOUT_TICKS);

        loginTimers.put(uuid, task);
    }

    public void authenticate(UUID uuid) {
        authenticated.add(uuid);
        cancelTimer(uuid);
    }

    public boolean isAuthenticated(UUID uuid) {
        return authenticated.contains(uuid);
    }

    public void onQuit(UUID uuid) {
        cleanup(uuid);
    }

    public void cancelAll() {
        loginTimers.values().forEach(t -> { if (t != null) t.cancel(); });
        loginTimers.clear();
    }

    private void cancelTimer(UUID uuid) {
        ScheduledTask t = loginTimers.remove(uuid);
        if (t != null) t.cancel();
    }

    private void cleanup(UUID uuid) {
        authenticated.remove(uuid);
        cancelTimer(uuid);
        playerIPs.remove(uuid);
    }
}
