package me.longka.neltraproop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NeltraCommand implements CommandExecutor {

    private final NeltraProOp plugin;

    public NeltraCommand(NeltraProOp plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {

            case "pas": {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("§c[NeltraProOp] Chỉ dùng trong game!");
                    return true;
                }
                if (!p.isOp()) {
                    p.sendMessage("§c[NeltraProOp] Bạn không phải OP.");
                    return true;
                }
                if (!plugin.getOpManager().isAllowed(p.getName())) {
                    p.sendMessage("§c[NeltraProOp] Bạn không có trong danh sách!");
                    return true;
                }
                if (plugin.getLoginManager().isAuthenticated(p.getUniqueId())) {
                    p.sendMessage("§a[NeltraProOp] Bạn đã xác thực rồi!");
                    return true;
                }
                if (args.length < 1) {
                    p.sendMessage("§c[NeltraProOp] Dùng: §f/pas <mật khẩu>");
                    return true;
                }
                if (args[0].equals(plugin.getOpManager().getPassword(p.getName()))) {
                    plugin.getLoginManager().authenticate(p.getUniqueId());
                    p.sendMessage("§a[NeltraProOp] §fXác thực §athành công§f! Chào §e" + p.getName() + "§f.");
                } else {
                    p.sendMessage("§c[NeltraProOp] §fMật khẩu §csai§f! Thử lại.");
                }
                return true;
            }

            case "login":
            case "register": {
                if (!(sender instanceof Player p)) return true;
                if (p.isOp() && plugin.getOpManager().isAllowed(p.getName())
                        && !plugin.getLoginManager().isAuthenticated(p.getUniqueId())) {
                    p.sendMessage("§6[NeltraProOp] §fOP phải dùng §a/pas §e<mật khẩu>§f.");
                }
                return true;
            }

            case "neltraproop": {
                if (!sender.isOp() && !sender.hasPermission("neltraproop.admin")) {
                    sender.sendMessage("§c[NeltraProOp] Bạn không có quyền!");
                    return true;
                }
                if (args.length < 1) {
                    sender.sendMessage("§6[NeltraProOp] §fLệnh:");
                    sender.sendMessage("§f  /neltraproop reload §7- Tải lại config");
                    sender.sendMessage("§f  /neltraproop info  §7- Thông tin plugin");
                    return true;
                }
                switch (args[0].toLowerCase()) {
                    case "reload" -> {
                        plugin.reloadConfig();
                        plugin.getOpManager().load();
                        sender.sendMessage("§a[NeltraProOp] §fReload thành công!");
                        sender.sendMessage("§7Dev For LongKa");
                    }
                    case "info" -> {
                        sender.sendMessage("§6[NeltraProOp] §fAntiOp + OP Password | Folia 1.21.1");
                        sender.sendMessage("§7Dev For LongKa");
                    }
                    default -> sender.sendMessage("§c[NeltraProOp] Lệnh không hợp lệ.");
                }
                return true;
            }
        }
        return false;
    }
}
