package me.longka.neltraproop;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import java.util.Set;

public class PlayerListener implements Listener {

    private final NeltraProOp plugin;
    private static final Set<String> ALLOWED_CMDS = Set.of("/login", "/register", "/pas");

    public PlayerListener(NeltraProOp plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        if (!player.isOp()) return;

        if (!plugin.getOpManager().isAllowed(player.getName())) {
            player.getScheduler().run(plugin, t -> {
                player.setOp(false);
                player.kickPlayer(
                    "§c[NeltraProOp] §fBạn §cKHÔNG §fcó trong danh sách OP!\n" +
                    "§7Liên hệ Admin nếu nhầm lẫn.\n§8Dev For LongKa"
                );
            }, null);
            return;
        }

        plugin.getLoginManager().onOpJoin(player);

        player.getScheduler().run(plugin, t -> {
            player.sendMessage("§6[NeltraProOp] §fChào §e" + player.getName() + "§f!");
            player.sendMessage("§fDùng §a/pas §e<mật khẩu> §fđể xác thực.");
            player.sendMessage("§fBạn có §c5 phút§f, nếu không sẽ bị §cban IP§f.");
        }, null);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.getLoginManager().onQuit(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player player = e.getPlayer();
        if (!player.isOp()) return;
        if (!plugin.getOpManager().isAllowed(player.getName())) return;
        if (plugin.getLoginManager().isAuthenticated(player.getUniqueId())) return;

        String cmd = e.getMessage().toLowerCase().split(" ")[0];
        if (!ALLOWED_CMDS.contains(cmd)) {
            e.setCancelled(true);
            player.sendMessage("§c[NeltraProOp] §fChưa xác thực! Dùng §a/pas §e<mật khẩu>§f.");
        }
    }
}
